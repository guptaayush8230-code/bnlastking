<?php
// admin.php - BN Last King Pro + Admin Panel
session_start();

// ========== DATABASE CONNECTION ==========
$db_path = __DIR__ . '/database.db';
try {
    $pdo = new PDO("sqlite:" . $db_path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// ========== AUTHENTICATION ==========
$admin_logged_in = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

// Handle Login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $user['username'];
        $_SESSION['admin_role'] = $user['role'];
        
        // Update last login
        $updateStmt = $pdo->prepare("UPDATE admin_users SET last_login = strftime('%s', 'now') WHERE id = ?");
        $updateStmt->execute([$user['id']]);
        
        header('Location: admin.php');
        exit;
    } else {
        $login_error = "Invalid username or password";
    }
}

// Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// ========== CRUD OPERATIONS ==========
// Add Key
if ($admin_logged_in && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_key'])) {
    $key_name = $_POST['key_name'] ?? '';
    $key_code = $_POST['key_code'] ?? '';
    $expiry_days = intval($_POST['expiry_days'] ?? 30);
    $expires_at = ($expiry_days > 0) ? time() + ($expiry_days * 86400) : null;
    
    if (!empty($key_name) && !empty($key_code)) {
        $stmt = $pdo->prepare("INSERT INTO keys (key_name, key_code, expires_at, created_by) VALUES (?, ?, ?, ?)");
        $stmt->execute([$key_name, $key_code, $expires_at, $_SESSION['admin_username']]);
        $success_msg = "Key added successfully!";
    } else {
        $error_msg = "Please fill all fields";
    }
}

// Delete Key
if ($admin_logged_in && isset($_GET['delete_key'])) {
    $stmt = $pdo->prepare("DELETE FROM keys WHERE id = ?");
    $stmt->execute([$_GET['delete_key']]);
    header('Location: admin.php');
    exit;
}

// Toggle Key Status
if ($admin_logged_in && isset($_GET['toggle_key'])) {
    $stmt = $pdo->prepare("UPDATE keys SET status = CASE WHEN status = 'active' THEN 'revoked' ELSE 'active' END WHERE id = ?");
    $stmt->execute([$_GET['toggle_key']]);
    header('Location: admin.php');
    exit;
}

// Update Server Config
if ($admin_logged_in && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_config'])) {
    $server_online = isset($_POST['server_online']) ? 1 : 0;
    $maintenance_mode = isset($_POST['maintenance_mode']) ? 1 : 0;
    $site_title = $_POST['site_title'] ?? 'BN Last King Pro +';
    $telegram_url = $_POST['telegram_url'] ?? '';
    $logo_url = $_POST['logo_url'] ?? '';
    
    $stmt = $pdo->prepare("UPDATE admin_config SET server_online = ?, maintenance_mode = ?, site_title = ?, updated_at = strftime('%s', 'now') WHERE id = 1");
    $stmt->execute([$server_online, $maintenance_mode, $site_title]);
    
    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ?, updated_at = strftime('%s', 'now') WHERE setting_key = 'telegram_url'");
    $stmt->execute([$telegram_url]);
    
    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ?, updated_at = strftime('%s', 'now') WHERE setting_key = 'logo_url'");
    $stmt->execute([$logo_url]);
    
    $success_msg = "Configuration updated!";
}

// Change Admin Password
if ($admin_logged_in && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    $stmt = $pdo->prepare("SELECT password_hash FROM admin_users WHERE username = ?");
    $stmt->execute([$_SESSION['admin_username']]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($current, $user['password_hash']) && $new === $confirm && strlen($new) >= 6) {
        $new_hash = password_hash($new, PASSWORD_DEFAULT);
        $updateStmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE username = ?");
        $updateStmt->execute([$new_hash, $_SESSION['admin_username']]);
        $success_msg = "Password changed successfully!";
    } else {
        $error_msg = "Invalid current password or new password doesn't match / too short";
    }
}

// ========== FETCH DATA ==========
// Get Server Config
$config = $pdo->query("SELECT * FROM admin_config WHERE id = 1")->fetch();
if (!$config) {
    $pdo->exec("INSERT INTO admin_config (id, server_online, maintenance_mode) VALUES (1, 1, 0)");
    $config = $pdo->query("SELECT * FROM admin_config WHERE id = 1")->fetch();
}

// Get Telegram URL
$telegram = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'telegram_url'")->fetch();
$telegram_url = $telegram ? $telegram['setting_value'] : 'https://t.me/BNOWNER';

// Get Logo URL
$logo = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'logo_url'")->fetch();
$logo_url = $logo ? $logo['setting_value'] : 'https://www.image2url.com/r2/default/images/1781278023925-dbc304f3-c2dc-4d27-a2d0-535a3b317ad0.jpg';

// Get All Keys
$keys = $pdo->query("SELECT * FROM keys ORDER BY id DESC")->fetchAll();

// Get Statistics
$stats = [];
$stats['total_keys'] = $pdo->query("SELECT COUNT(*) FROM keys")->fetchColumn();
$stats['active_keys'] = $pdo->query("SELECT COUNT(*) FROM keys WHERE status = 'active' AND (expires_at IS NULL OR expires_at > strftime('%s', 'now'))")->fetchColumn();
$stats['expired_keys'] = $pdo->query("SELECT COUNT(*) FROM keys WHERE expires_at IS NOT NULL AND expires_at <= strftime('%s', 'now')")->fetchColumn();
$stats['bound_keys'] = $pdo->query("SELECT COUNT(*) FROM keys WHERE bound_device IS NOT NULL")->fetchColumn();
$stats['recent_logins'] = $pdo->query("SELECT COUNT(*) FROM login_logs WHERE login_time > strftime('%s', 'now') - 86400")->fetchColumn();

// Get Recent Logins
$recent_logins = $pdo->query("SELECT * FROM login_logs ORDER BY login_time DESC LIMIT 20")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BN Last King Pro + | Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=El+Messiri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #00ff88;
            --primary-dim: #00cc6a;
            --accent: #00e5ff;
            --bg-dark: #06060a;
            --bg-card: #0c0c14;
            --bg-input: #10101a;
            --text-primary: #e8e8e8;
            --text-secondary: #6a6a7a;
            --border: #1a1a28;
            --error: #ff2e63;
            --warning: #ffaa00;
        }
        body {
            font-family: 'El Messiri', sans-serif;
            background: var(--bg-dark);
            color: var(--text-primary);
            min-height: 100vh;
        }
        .admin-header {
            position: fixed;
            top: 0; left: 0; right: 0;
            background: rgba(6,6,10,0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border);
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
        }
        .admin-header h1 {
            font-size: 1.2rem;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .admin-header .logout-btn {
            padding: 8px 20px;
            background: rgba(255,46,99,0.1);
            border: 1px solid rgba(255,46,99,0.3);
            border-radius: 8px;
            color: var(--error);
            text-decoration: none;
            font-size: 0.8rem;
            transition: all 0.3s;
        }
        .admin-header .logout-btn:hover {
            background: rgba(255,46,99,0.2);
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 80px 24px 40px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            text-align: center;
        }
        .stat-card .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
        }
        .stat-card .stat-label {
            font-size: 0.7rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-top: 8px;
        }
        .section {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 24px;
            margin-bottom: 30px;
        }
        .section h2 {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: var(--primary);
            border-left: 3px solid var(--primary);
            padding-left: 12px;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--text-secondary);
            margin-bottom: 6px;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text-primary);
            font-family: inherit;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--primary);
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
        }
        .checkbox-group input {
            width: 18px;
            height: 18px;
        }
        button {
            background: linear-gradient(135deg, var(--primary), var(--primary-dim));
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            color: #0a0a0f;
            font-weight: 700;
            cursor: pointer;
            font-family: inherit;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        th {
            color: var(--primary);
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
        }
        .badge-active { background: rgba(0,255,136,0.15); color: var(--primary); }
        .badge-expired { background: rgba(255,46,99,0.15); color: var(--error); }
        .badge-revoked { background: rgba(255,170,0,0.15); color: var(--warning); }
        .action-btn {
            background: transparent;
            padding: 4px 10px;
            margin: 0 2px;
            font-size: 0.7rem;
            border: 1px solid var(--border);
            color: var(--text-primary);
        }
        .delete-btn { border-color: var(--error); color: var(--error); }
        .login-form {
            max-width: 400px;
            margin: 100px auto;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 40px;
        }
        .msg { padding: 12px; border-radius: 10px; margin-bottom: 20px; }
        .msg-success { background: rgba(0,255,136,0.1); border: 1px solid var(--primary); color: var(--primary); }
        .msg-error { background: rgba(255,46,99,0.1); border: 1px solid var(--error); color: var(--error); }
        .row-2cols {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        @media (max-width: 768px) {
            .row-2cols { grid-template-columns: 1fr; }
            .container { padding: 70px 16px 30px; }
            table { display: block; overflow-x: auto; }
        }
    </style>
</head>
<body>

<?php if (!$admin_logged_in): ?>
    <!-- Login Form -->
    <div class="login-form">
        <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="font-size: 1.5rem; background: linear-gradient(135deg, var(--primary), var(--accent)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">BN Admin Portal</h1>
            <p style="color: var(--text-secondary); font-size: 0.8rem;">Secure Authentication Required</p>
        </div>
        <?php if (isset($login_error)): ?>
            <div class="msg msg-error"><?php echo $login_error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" name="login" style="width: 100%;">Login to Admin Panel</button>
        </form>
        <div style="text-align: center; margin-top: 20px; font-size: 0.7rem; color: var(--text-secondary);">
            Default: admin / admin123
        </div>
    </div>
<?php else: ?>
    <!-- Admin Panel -->
    <header class="admin-header">
        <h1>⚡ BN Last King Pro + | ADMIN PANEL</h1>
        <a href="?logout=1" class="logout-btn">✖ LOGOUT</a>
    </header>

    <div class="container">
        <?php if (isset($success_msg)): ?>
            <div class="msg msg-success" style="margin-bottom: 20px;">✓ <?php echo $success_msg; ?></div>
        <?php endif; ?>
        <?php if (isset($error_msg)): ?>
            <div class="msg msg-error" style="margin-bottom: 20px;">✗ <?php echo $error_msg; ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-value"><?php echo $stats['total_keys']; ?></div><div class="stat-label">Total Keys</div></div>
            <div class="stat-card"><div class="stat-value"><?php echo $stats['active_keys']; ?></div><div class="stat-label">Active Keys</div></div>
            <div class="stat-card"><div class="stat-value"><?php echo $stats['expired_keys']; ?></div><div class="stat-label">Expired Keys</div></div>
            <div class="stat-card"><div class="stat-value"><?php echo $stats['bound_keys']; ?></div><div class="stat-label">Bound Devices</div></div>
            <div class="stat-card"><div class="stat-value"><?php echo $stats['recent_logins']; ?></div><div class="stat-label">Logins (24h)</div></div>
        </div>

        <div class="row-2cols">
            <!-- Server Configuration -->
            <div class="section">
                <h2>🔧 Server Configuration</h2>
                <form method="POST">
                    <div class="checkbox-group">
                        <input type="checkbox" name="server_online" id="server_online" <?php echo $config['server_online'] ? 'checked' : ''; ?>>
                        <label for="server_online">Server Online</label>
                    </div>
                    <div class="checkbox-group">
                        <input type="checkbox" name="maintenance_mode" id="maintenance_mode" <?php echo $config['maintenance_mode'] ? 'checked' : ''; ?>>
                        <label for="maintenance_mode">Maintenance Mode</label>
                    </div>
                    <div class="form-group">
                        <label>Site Title</label>
                        <input type="text" name="site_title" value="<?php echo htmlspecialchars($config['site_title'] ?? 'BN Last King Pro +'); ?>">
                    </div>
                    <div class="form-group">
                        <label>Telegram Contact URL</label>
                        <input type="url" name="telegram_url" value="<?php echo htmlspecialchars($telegram_url); ?>">
                    </div>
                    <div class="form-group">
                        <label>Logo Image URL</label>
                        <input type="url" name="logo_url" value="<?php echo htmlspecialchars($logo_url); ?>">
                    </div>
                    <button type="submit" name="update_config">Save Configuration</button>
                </form>
            </div>

            <!-- Add New Key -->
            <div class="section">
                <h2>➕ Add New Access Key</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Key Name (User/Customer)</label>
                        <input type="text" name="key_name" placeholder="e.g., John Doe" required>
                    </div>
                    <div class="form-group">
                        <label>Key Code</label>
                        <input type="text" name="key_code" placeholder="BN-PRO-XXXX-XXXX" required>
                    </div>
                    <div class="form-group">
                        <label>Expiry Days (0 = Lifetime)</label>
                        <input type="number" name="expiry_days" value="30">
                    </div>
                    <button type="submit" name="add_key">Generate Key</button>
                </form>
            </div>
        </div>

        <!-- Change Password -->
        <div class="section">
            <h2>🔐 Change Admin Password</h2>
            <form method="POST" style="max-width: 400px;">
                <div class="form-group">
                    <label>Current Password</label>
                    <input type="password" name="current_password" required>
                </div>
                <div class="form-group">
                    <label>New Password (min 6 chars)</label>
                    <input type="password" name="new_password" required>
                </div>
                <div class="form-group">
                    <label>Confirm New Password</label>
                    <input type="password" name="confirm_password" required>
                </div>
                <button type="submit" name="change_password">Change Password</button>
            </form>
        </div>

        <!-- Manage Keys -->
        <div class="section">
            <h2>🔑 Manage Access Keys</h2>
            <table>
                <thead>
                    <tr><th>ID</th><th>Key Name</th><th>Key Code</th><th>Expires</th><th>Device Bound</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($keys as $key): 
                        $expired = $key['expires_at'] && $key['expires_at'] <= time();
                        $status = $key['status'];
                        if ($expired && $status == 'active') $status = 'expired';
                    ?>
                    <tr>
                        <td><?php echo $key['id']; ?></td>
                        <td><?php echo htmlspecialchars($key['key_name']); ?></td>
                        <td><code><?php echo htmlspecialchars($key['key_code']); ?></code></td>
                        <td><?php echo $key['expires_at'] ? date('Y-m-d', $key['expires_at']) : 'Lifetime'; ?></td>
                        <td><?php echo $key['bound_device'] ? substr($key['bound_device'], 0, 20) . '...' : 'Not bound'; ?></td>
                        <td><span class="badge badge-<?php echo $status; ?>"><?php echo strtoupper($status); ?></span></td>
                        <td>
                            <a href="?toggle_key=<?php echo $key['id']; ?>" class="action-btn">Toggle</a>
                            <a href="?delete_key=<?php echo $key['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Delete this key?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($keys)): ?>
                    <tr><td colspan="7" style="text-align: center;">No keys found. Add your first key above.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Recent Login Logs -->
        <div class="section">
            <h2>📋 Recent Login Activity</h2>
            <table>
                <thead><tr><th>Time</th><th>Key Code</th><th>Device ID</th><th>IP Address</th><th>Status</th></tr></thead>
                <tbody>
                    <?php foreach ($recent_logins as $log): ?>
                    <tr>
                        <td><?php echo date('Y-m-d H:i:s', $log['login_time']); ?></td>
                        <td><code><?php echo htmlspecialchars(substr($log['key_code'], 0, 20)); ?></code></td>
                        <td><?php echo htmlspecialchars(substr($log['device_id'], 0, 20)) . '...'; ?></td>
                        <td><?php echo htmlspecialchars($log['ip_address'] ?? 'Unknown'); ?></td>
                        <td><span class="badge badge-<?php echo $log['status']; ?>"><?php echo $log['status']; ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
</body>
</html>