<?php
// index.php - BN Last King Pro + User Login Portal
session_start();

// ========== DATABASE CONNECTION ==========
$db_path = __DIR__ . '/database.db';
try {
    $pdo = new PDO("sqlite:" . $db_path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection Error");
}

// ========== GET CONFIGURATION ==========
$config = $pdo->query("SELECT * FROM admin_config WHERE id = 1")->fetch();
if (!$config) {
    $pdo->exec("INSERT INTO admin_config (id, server_online, maintenance_mode) VALUES (1, 1, 0)");
    $config = ['server_online' => 1, 'maintenance_mode' => 0, 'site_title' => 'BN Last King Pro +'];
}

$telegram = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'telegram_url'")->fetch();
$telegram_url = $telegram ? $telegram['setting_value'] : 'https://t.me/BNOWNER';

$logo = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'logo_url'")->fetch();
$logo_url = $logo ? $logo['setting_value'] : 'https://www.image2url.com/r2/default/images/1781278023925-dbc304f3-c2dc-4d27-a2d0-535a3b317ad0.jpg';

$server_online = $config['server_online'] == 1;
$maintenance_mode = $config['maintenance_mode'] == 1;

// ========== HANDLE LOGIN REQUEST (AJAX) ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    
    $key_code = trim($_POST['key'] ?? '');
    $device_id = $_POST['device_id'] ?? '';
    
    if (empty($key_code) || empty($device_id)) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }
    
    if (!$server_online) {
        echo json_encode(['success' => false, 'message' => 'Server is offline']);
        exit;
    }
    
    if ($maintenance_mode) {
        echo json_encode(['success' => false, 'message' => 'Under maintenance']);
        exit;
    }
    
    // Get key from database
    $stmt = $pdo->prepare("SELECT * FROM keys WHERE key_code = ?");
    $stmt->execute([$key_code]);
    $key = $stmt->fetch();
    
    if (!$key) {
        // Log failed attempt
        $logStmt = $pdo->prepare("INSERT INTO login_logs (key_code, device_id, ip_address, user_agent, status) VALUES (?, ?, ?, ?, 'failed')");
        $logStmt->execute([$key_code, $device_id, $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['HTTP_USER_AGENT'] ?? '']);
        echo json_encode(['success' => false, 'message' => 'Invalid access key']);
        exit;
    }
    
    // Check status
    if ($key['status'] !== 'active') {
        echo json_encode(['success' => false, 'message' => 'This key has been revoked']);
        exit;
    }
    
    // Check expiration
    if ($key['expires_at'] && $key['expires_at'] <= time()) {
        // Update status to expired
        $updateStmt = $pdo->prepare("UPDATE keys SET status = 'expired' WHERE id = ?");
        $updateStmt->execute([$key['id']]);
        echo json_encode(['success' => false, 'message' => 'This key has expired']);
        exit;
    }
    
    // Check device binding
    if ($key['bound_device'] && $key['bound_device'] !== $device_id) {
        echo json_encode(['success' => false, 'message' => 'This key is already in use on another device (1 key = 1 device)']);
        exit;
    }
    
    // Bind device if not bound
    if (!$key['bound_device']) {
        $bindStmt = $pdo->prepare("UPDATE keys SET bound_device = ? WHERE id = ?");
        $bindStmt->execute([$device_id, $key['id']]);
    }
    
    // Update last login
    $loginStmt = $pdo->prepare("UPDATE keys SET last_login = ? WHERE id = ?");
    $loginStmt->execute([time(), $key['id']]);
    
    // Log successful login
    $logStmt = $pdo->prepare("INSERT INTO login_logs (key_code, device_id, ip_address, user_agent, status) VALUES (?, ?, ?, ?, 'success')");
    $logStmt->execute([$key_code, $device_id, $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['HTTP_USER_AGENT'] ?? '']);
    
    // Calculate remaining time
    $remaining = null;
    if ($key['expires_at']) {
        $remaining_days = ceil(($key['expires_at'] - time()) / 86400);
        $remaining = $remaining_days . ' days';
    } else {
        $remaining = 'Lifetime';
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'Authentication successful',
        'key_name' => $key['key_name'],
        'remaining' => $remaining,
        'redirect' => 'https://deluxe-dusk-293602.netlify.app/'
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($config['site_title'] ?? 'BN Last King Pro +'); ?> | Login</title>
    <link href="https://fonts.googleapis.com/css2?family=El+Messiri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #00ff88;
            --primary-dim: #00cc6a;
            --accent: #00e5ff;
            --bg-dark: #06060a;
            --bg-card: #0c0c14;
            --bg-input: #10101a;
            --text-primary: #e8e8e8;
            --text-secondary: #6a6a7a;
            --border: #1a1a28;
            --error: #ff2e63;
            --warning: #ffaa00;
        }
        body {
            font-family: 'El Messiri', sans-serif;
            background: var(--bg-dark);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }
        #matrix-canvas {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: 0;
            pointer-events: none;
            opacity: 0.035;
        }
        .bg-grid {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: 0;
            pointer-events: none;
            background-image: linear-gradient(rgba(0,255,136,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,136,0.025) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: gridMove 25s linear infinite;
        }
        @keyframes gridMove { 100% { transform: translate(50px, 50px); } }
        .scan-beam {
            position: fixed;
            top: -200px; left: 0;
            width: 100%; height: 200px;
            background: linear-gradient(180deg, transparent, rgba(0,255,136,0.025), transparent);
            z-index: 0;
            pointer-events: none;
            animation: scanBeam 7s linear infinite;
        }
        @keyframes scanBeam { 100% { top: 100vh; } }
        .login-header {
            position: fixed;
            top: 0; left: 0; right: 0;
            padding: 14px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--border);
            background: rgba(6,6,10,0.88);
            backdrop-filter: blur(20px);
            z-index: 100;
        }
        .header-left {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .header-shield {
            width: 32px; height: 32px;
            border: 2px solid var(--primary);
            border-radius: 7px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .header-shield svg {
            width: 16px; height: 16px;
            fill: var(--primary);
        }
        .header-brand {
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .server-status {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 100px;
            font-size: 0.62rem;
            letter-spacing: 1.8px;
            border: 1px solid var(--border);
        }
        .server-status .dot {
            width: 6px; height: 6px;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        @keyframes pulse { 50% { opacity: 0.4; transform: scale(0.7); } }
        .server-status.online .dot { background: var(--primary); }
        .server-status.offline .dot { background: var(--error); animation: none; }
        .server-status.maintenance .dot { background: var(--warning); }
        .main-content {
            position: relative;
            z-index: 10;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 80px 20px;
        }
        .login-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 22px;
            width: 100%;
            max-width: 440px;
            position: relative;
            overflow: hidden;
        }
        .login-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--primary), var(--accent), transparent);
            animation: borderGlow 4s linear infinite;
            background-size: 200% 100%;
        }
        @keyframes borderGlow { 100% { background-position: 200% 0; } }
        .card-top {
            padding: 36px 32px 20px;
            text-align: center;
        }
        .logo-wrapper {
            width: 120px;
            height: 120px;
            margin: 0 auto 22px;
            position: relative;
        }
        .logo-img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 2.5px solid var(--primary);
            box-shadow: 0 0 25px rgba(0,255,136,0.15);
        }
        .card-title {
            font-size: 1.4rem;
            font-weight: 700;
            letter-spacing: 2px;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .card-subtitle {
            font-size: 0.72rem;
            color: var(--text-secondary);
            letter-spacing: 1.8px;
            text-transform: uppercase;
        }
        .terminal-decor {
            margin: 4px 28px 14px;
            padding: 10px 14px;
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.04);
            border-radius: 8px;
            font-size: 0.65rem;
            color: var(--text-secondary);
        }
        .t-green { color: var(--primary); }
        .t-cyan { color: var(--accent); }
        .msg-box {
            margin: 0 28px 12px;
            padding: 10px 14px;
            border-radius: 10px;
            font-size: 0.78rem;
            display: none;
        }
        .msg-box.show { display: flex; align-items: center; gap: 8px; }
        .msg-box.error { background: rgba(255,46,99,0.06); border: 1px solid rgba(255,46,99,0.15); color: var(--error); }
        .msg-box.success { background: rgba(0,255,136,0.06); border: 1px solid rgba(0,255,136,0.15); color: var(--primary); }
        .card-body { padding: 0 28px 6px; }
        .input-group { margin-bottom: 16px; }
        .input-label {
            display: block;
            font-size: 0.68rem;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }
        .input-container { position: relative; }
        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            width: 18px; height: 18px;
        }
        .input-icon svg { fill: var(--text-secondary); }
        .key-input {
            width: 100%;
            padding: 14px 14px 14px 44px;
            background: var(--bg-input);
            border: 1.5px solid var(--border);
            border-radius: 12px;
            color: var(--text-primary);
            font-family: inherit;
            font-size: 0.95rem;
            letter-spacing: 2px;
            outline: none;
        }
        .key-input:focus { border-color: var(--primary); }
        .validity-display {
            display: none;
            padding: 9px 14px;
            background: rgba(0,255,136,0.04);
            border: 1px solid rgba(0,255,136,0.1);
            border-radius: 10px;
            margin-bottom: 14px;
            font-size: 0.75rem;
        }
        .validity-display.show { display: flex; align-items: center; gap: 8px; }
        .login-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dim));
            border: none;
            border-radius: 12px;
            color: #0a0a0f;
            font-family: inherit;
            font-size: 1rem;
            font-weight: 700;
            letter-spacing: 3px;
            text-transform: uppercase;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .login-btn .spinner {
            display: none;
            width: 20px; height: 20px;
            border: 2.5px solid rgba(0,0,0,0.2);
            border-top-color: #0a0a0f;
            border-radius: 50%;
            animation: spinLoader 0.6s linear infinite;
        }
        .login-btn.loading .spinner { display: block; }
        .login-btn.loading .btn-text,
        .login-btn.loading svg { display: none; }
        @keyframes spinLoader { to { transform: rotate(360deg); } }
        .separator {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 16px 28px;
        }
        .separator .line { flex: 1; height: 1px; background: var(--border); }
        .card-footer { padding: 4px 28px 28px; }
        .help-link {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px;
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 600;
            letter-spacing: 2px;
            text-transform: uppercase;
        }
        .help-link:hover { border-color: rgba(0,229,255,0.3); color: var(--accent); }
        .card-footer-text {
            text-align: center;
            margin-top: 14px;
            font-size: 0.72rem;
            color: var(--text-secondary);
        }
        .card-footer-text a { color: var(--accent); text-decoration: none; }
        .loading-modal {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.92);
            backdrop-filter: blur(20px);
            z-index: 2000;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
        }
        .loading-modal.active { opacity: 1; visibility: visible; }
        .loading-card {
            background: linear-gradient(145deg, #0c0c14, #08080c);
            border: 1px solid rgba(0,255,136,0.3);
            border-radius: 32px;
            padding: 45px 35px;
            text-align: center;
            width: 380px;
            max-width: 85vw;
        }
        .loading-title {
            font-size: 1.6rem;
            font-weight: 800;
            letter-spacing: 4px;
            background: linear-gradient(135deg, #00ff88, #00e5ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        .progress-bar-container {
            width: 100%;
            height: 3px;
            background: rgba(255,255,255,0.08);
            border-radius: 3px;
            margin: 20px 0;
            overflow: hidden;
        }
        .progress-fill {
            width: 0%;
            height: 100%;
            background: linear-gradient(90deg, #00ff88, #00e5ff);
            transition: width 0.05s linear;
        }
        .login-footer {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            padding: 12px 20px;
            text-align: center;
            font-size: 0.65rem;
            color: var(--text-secondary);
            border-top: 1px solid var(--border);
            background: rgba(6,6,10,0.8);
            backdrop-filter: blur(10px);
            z-index: 10;
        }
        @media (max-width: 480px) {
            .card-top { padding: 28px 20px 16px; }
            .logo-wrapper, .logo-img { width: 100px; height: 100px; }
            .card-body { padding: 0 20px 4px; }
            .card-footer { padding: 4px 20px 22px; }
        }
    </style>
</head>
<body>

<canvas id="matrix-canvas"></canvas>
<div class="bg-grid"></div>
<div class="scan-beam"></div>

<header class="login-header">
    <div class="header-left">
        <div class="header-shield"><svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg></div>
        <div class="header-brand"><?php echo htmlspecialchars($config['site_title'] ?? 'BN Last King Pro +'); ?></div>
    </div>
    <div class="server-status <?php echo !$server_online ? 'offline' : ($maintenance_mode ? 'maintenance' : 'online'); ?>">
        <div class="dot"></div>
        <span><?php echo !$server_online ? 'Offline' : ($maintenance_mode ? 'Maintenance' : 'Online'); ?></span>
    </div>
</header>

<div class="main-content">
    <div class="login-card">
        <div class="card-top">
            <div class="logo-wrapper">
                <img src="<?php echo htmlspecialchars($logo_url); ?>" alt="Logo" class="logo-img">
            </div>
            <h1 class="card-title"><?php echo htmlspecialchars($config['site_title'] ?? 'BN Last King Pro +'); ?></h1>
            <p class="card-subtitle">Secure Authentication Portal</p>
        </div>

        <div class="terminal-decor">
            <div class="t-line"><span class="t-green">></span> <span class="t-dim">system.auth</span> <span class="t-cyan">initializing</span>...</div>
            <div class="t-line"><span class="t-green">></span> encryption: <span class="t-green">AES-256</span> <span class="t-dim">active</span></div>
            <div class="t-line"><span class="t-green">></span> awaiting key...</div>
        </div>

        <div class="msg-box" id="msgBox"><span id="msgText"></span></div>

        <div class="card-body">
            <div class="input-group">
                <label class="input-label">Access Key</label>
                <div class="input-container">
                    <div class="input-icon"><svg viewBox="0 0 24 24"><path d="M12.65 10A5.99 5.99 0 0 0 7 6c-3.31 0-6 2.69-6 6s2.69 6 6 6a5.99 5.99 0 0 0 5.65-4H17v4h4v-4h2v-4H12.65zM7 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg></div>
                    <input type="text" class="key-input" id="keyInput" placeholder="Enter your access key" autocomplete="off">
                </div>
            </div>

            <div class="validity-display" id="validityInfo"><div id="validityText"></div></div>

            <button class="login-btn" id="loginBtn">
                <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                <span class="btn-text">Authenticate</span>
                <div class="spinner"></div>
            </button>
        </div>

        <div class="separator"><div class="line"></div><div class="sep-text">Need Help?</div><div class="line"></div></div>

        <div class="card-footer">
            <a href="<?php echo htmlspecialchars($telegram_url); ?>" target="_blank" class="help-link">
                <svg viewBox="0 0 24 24" width="16" height="16"><path d="M20.665 3.717l-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l.002.001-.314 4.692c.46 0 .663-.211.921-.46l2.211-2.15 4.599 3.397c.848.467 1.457.227 1.668-.785l3.019-14.228c.309-1.239-.473-1.8-1.282-1.434z"/></svg>
                Contact Admin
            </a>
            <p class="card-footer-text">Don't have a key? <a href="<?php echo htmlspecialchars($telegram_url); ?>" target="_blank">Get Access</a></p>
        </div>
    </div>
</div>

<div id="loadingModal" class="loading-modal">
    <div class="loading-card">
        <div class="loading-title">AUTHENTICATED</div>
        <div class="loading-sub">Establishing Secure Gateway</div>
        <div class="progress-bar-container"><div class="progress-fill" id="loadProgress"></div></div>
        <div class="loading-status" id="loadStatus">[>] INITIALIZING SESSION...</div>
    </div>
</div>

<footer class="login-footer">&copy; 2026 <span> <?php echo htmlspecialchars($config['site_title'] ?? 'BN Last King Pro +'); ?></span> — Secured & Encrypted</footer>

<script>
function getDeviceId() {
    let deviceId = localStorage.getItem('device_id');
    if (!deviceId) {
        deviceId = 'dev_' + Date.now() + '_' + Math.random().toString(36).substr(2, 16);
        localStorage.setItem('device_id', deviceId);
    }
    return deviceId;
}

const deviceId = getDeviceId();
const keyInput = document.getElementById('keyInput');
const loginBtn = document.getElementById('loginBtn');
const msgBox = document.getElementById('msgBox');
const msgText = document.getElementById('msgText');
const validityInfo = document.getElementById('validityInfo');
const validityText = document.getElementById('validityText');
const loadingModal = document.getElementById('loadingModal');
const loadProgress = document.getElementById('loadProgress');
const loadStatus = document.getElementById('loadStatus');

function showMsg(type, text) {
    msgBox.className = 'msg-box show ' + type;
    msgText.textContent = text;
}

function hideMsg() { msgBox.className = 'msg-box'; }

function showAttractiveLoading() {
    loadingModal.classList.add('active');
    let progress = 0;
    const statusList = ["[>] INITIALIZING SESSION...", "[*] VERIFYING CREDENTIALS...", "[~] ESTABLISHING SECURE TUNNEL...", "[#] LOADING USER PROFILE...", "[@] SYNCING ENCRYPTION KEYS...", "[!] FINALIZING HANDSHAKE...", "[+] ACCESS GRANTED!"];
    let statusIndex = 0;
    loadStatus.innerText = statusList[0];
    const interval = setInterval(() => {
        progress += Math.floor(Math.random() * 8) + 4;
        if (progress >= 100) {
            progress = 100;
            loadProgress.style.width = '100%';
            clearInterval(interval);
            loadStatus.innerText = "[✔] REDIRECTING TO PORTAL...";
            setTimeout(() => { window.location.href = "https://deluxe-dusk-293602.netlify.app/"; }, 400);
        } else {
            loadProgress.style.width = progress + '%';
            if (progress > 20 && statusIndex < statusList.length - 1 && progress % 18 < 5) {
                statusIndex++;
                loadStatus.innerText = statusList[statusIndex];
            }
        }
    }, 45);
}

async function handleLogin() {
    const key = keyInput.value.trim();
    if (!key) { showMsg('error', 'Please enter your access key'); keyInput.focus(); return; }
    
    loginBtn.classList.add('loading');
    loginBtn.disabled = true;
    hideMsg();
    validityInfo.classList.remove('show');
    
    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
            body: 'key=' + encodeURIComponent(key) + '&device_id=' + encodeURIComponent(deviceId)
        });
        const data = await response.json();
        
        if (data.success) {
            localStorage.setItem('bnkey', key);
            localStorage.setItem('bnkey_name', data.key_name);
            validityText.innerHTML = '✓ Authenticated: <span>' + data.key_name + '</span> | ' + data.remaining;
            validityInfo.classList.add('show');
            setTimeout(() => { showAttractiveLoading(); }, 500);
        } else {
            loginBtn.classList.remove('loading');
            loginBtn.disabled = false;
            showMsg('error', data.message);
        }
    } catch (err) {
        loginBtn.classList.remove('loading');
        loginBtn.disabled = false;
        showMsg('error', 'Connection error. Please try again.');
    }
}

keyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') handleLogin(); });
document.getElementById('loginBtn').addEventListener('click', handleLogin);

// Matrix Rain Effect
const canvas = document.getElementById('matrix-canvas');
const ctx = canvas.getContext('2d');
function resizeCanvas() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
resizeCanvas();
window.addEventListener('resize', resizeCanvas);
const chars = 'BNLASTKING01PRO+HACK';
const fontSize = 14;
let columns = Math.floor(canvas.width / fontSize);
let drops = Array(columns).fill(1);
function drawMatrix() {
    ctx.fillStyle = 'rgba(6, 6, 10, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#00ff88';
    ctx.font = fontSize + 'px monospace';
    for (let i = 0; i < drops.length; i++) {
        ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
    }
}
setInterval(drawMatrix, 50);
window.addEventListener('resize', () => { columns = Math.floor(canvas.width / fontSize); drops = Array(columns).fill(1); });
</script>
</body>
</html>